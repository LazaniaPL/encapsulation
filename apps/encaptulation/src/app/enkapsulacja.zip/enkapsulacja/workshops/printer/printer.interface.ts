export interface Printer{
    print(data:string):void;
}
